load "prime.m";
load "file_terms_irr_poly.m";
Fp2:=ExtensionField<Fp,z|&+[terms_irr_poly[i]*z^(i-1): i in [1..#terms_irr_poly]]>;

printf "\n p:=%o;",p;
printf "\n Defining polynomial=%o",DefiningPolynomial(Fp2);

load "list_ss_j_inv.m";

Number_of_curves:=#seq_j_inv;

Number_of_j_jp_isogenous_cases:=0;
list_my_cycles:=[];

R2<x,y>:=PolynomialRing(Fp2,2);

//The modular polynomial construction
R1<x>:=PolynomialRing(Fp2);



for l in PrimesInInterval(2,59) do	
	
	mod_poly:=R2!ClassicalModularPolynomial(l);
	
	
	
	s2:=0;s3:=0;s4:=0;
	bs2:=0;bs3:=0;bs4:=0;
	d_2_i1_not_eq_i2:=0;d_3_i1_not_eq_i2:=0;d_4_i1_not_eq_i2:=0;
	
	for i in [1..#seq_j_inv] do
	//for i in [1..2] do
		sign:=0;
		j:=seq_j_inv[i];	
		j0:=seq_j_inv[i];
		
		
		
		f:=Evaluate(mod_poly,y,j);
		set_of_roots:=Roots(UnivariatePolynomial(f));
		all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
		p_th_power_all_roots:=[(all_roots[i])^p : i in [1..#all_roots]];
		isogeneous_list_now:=[j];
		
		
		repeat			
			if(not IsDisjoint(SequenceToSet(all_roots),SequenceToSet(p_th_power_all_roots))) then
				s2:=s2+1;		
				for i in [1..#all_roots] do
					j1:=all_roots[i];
					for t in [1..#p_th_power_all_roots] do
						j2:=p_th_power_all_roots[t];
						if(j1 eq j2) then
							//dist_2:=dist_2+1;
							if(j2 ne (j1^p)) then
								d_2_i1_not_eq_i2:=d_2_i1_not_eq_i2+1;
							end if;
							Append(~isogeneous_list_now,j1);
							target_isogeny_initiating_index:=#isogeneous_list_now;
							target_isogeny_ending_index:=#isogeneous_list_now;
							sign:=1;
							break;
						end if;
					end for;
				
					if(sign eq 1) then
						break;
					end if;
					
				end for;
				bs2:=s2-d_2_i1_not_eq_i2;
		
			else
				for i in [1..#all_roots] do
					j1:=all_roots[i];
					for t in [1..#p_th_power_all_roots] do
						j2:=p_th_power_all_roots[t];
						tmp:=Evaluate(mod_poly,[j1,j2]);
						if(tmp eq 0) then
							//dist_3:=dist_3+1;
							s3:=s3+1;
							if(j2 ne (j1^p)) then
								d_3_i1_not_eq_i2:=d_3_i1_not_eq_i2+1;
							end if;
							Append(~isogeneous_list_now,j1);
							target_isogeny_initiating_index:=#isogeneous_list_now;
							Append(~isogeneous_list_now,j2);
							target_isogeny_ending_index:=#isogeneous_list_now;
							sign:=1;
							break;
						end if;
					end for;
					if(sign eq 1) then
						break;
					end if;
				end for;
				bs3:=s3-d_3_i1_not_eq_i2;
				if(sign eq 1) then
					break;
				end if;	
			
				for i in [1..#all_roots] do
					j1:=all_roots[i];
					for t in [1..#p_th_power_all_roots] do
						j2:=p_th_power_all_roots[t];	
						f1:=Evaluate(mod_poly,y,j1);
						f2:=Evaluate(mod_poly,y,j2);
					 				gcd:=GreatestCommonDivisor(UnivariatePolynomial(f1),UnivariatePolynomial(f2));
						if(Degree(gcd) ne 0) then
							//dist_4:=dist_4+1;
							s4:=s4+1;	
							if(j2 ne (j1^p)) then
								d_4_i1_not_eq_i2:=d_4_i1_not_eq_i2+1;
							end if;
							any_root:=Random(Roots(gcd))[1];
							Append(~isogeneous_list_now,j1);
							target_isogeny_initiating_index:=#isogeneous_list_now;
							Append(~isogeneous_list_now,any_root);
							Append(~isogeneous_list_now,j2);
							target_isogeny_ending_index:=#isogeneous_list_now;
							//printf "\n j1=%o, j2=%o END", j1,j2;
					 		sign:=1;
							break;
						end if;
					end for;
					bs4:=s4-d_4_i1_not_eq_i2;
					if(sign eq 1) then
						break;
					end if;	
				end for;
				//printf "\n i=%o, itr over, s2=%o, s3=%o, s4=%o, sign=%o",i,s2,s3,s4, sign;
				if(sign eq 0) then
				
					j:=Random(set_of_roots)[1];
				//printf "j=%o --> ",j;		
					f:=Evaluate(mod_poly,y,j);
					set_of_roots:=Roots(UnivariatePolynomial(f));
					all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
					p_th_power_all_roots:=[(all_roots[i])^p : i in [1..#all_roots]];
					Append(~isogeneous_list_now,j);
	
				end if;
			end if;
		until(sign eq 1);
	end for;
	printf "\n l=%o,s2=%o, bs2=%o, Percentage_bs2=%o, s3=%o, bs3=%o, Percentage_bs3=%o, s4=%o, bs4=%o, Percentage_bs4=%o ",l,s2,bs2, Ceiling((bs2*100)/Number_of_curves),s3,bs3, Ceiling((bs3*100)/Number_of_curves),s4,bs4, Ceiling((bs4*100)/Number_of_curves);
end for;		


