terms_irr_poly:=
[ 74789, 38302, 1 ]
;
