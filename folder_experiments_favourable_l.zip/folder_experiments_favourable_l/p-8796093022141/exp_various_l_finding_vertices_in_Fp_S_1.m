p:= 8796093022151
;
terms_irr_poly:= [1, 0, 1]
;
seq_j_inv:= [[5781490755991, 7232094326646], [7259248381444, 861396845559], [8569477027555, 7927942820753], [8157784515063, 8110483657717], [4868199894543, 8176407604737], [1845554395173, 8733310766967], [3223830057957, 2927441559298], [5678879543119, 8053714442666], [2854414094619, 4997621633659], [1222361935678, 6260331620390], [3824135936104, 858392441061], [8616651463184, 5655245898722], [4737645893828, 5376630580599], [345952510843, 131958281359], [7421702326571, 3503550403156], [4398221948064, 6467909317265], [4603081125504, 681599558936], [4203134796194, 892081502124], [555823778409, 7670054165569], [4010572478845, 849097282886], [5856108702146, 1106661052834], [5951280493956, 3011837135132], [1050943013393, 577063328393], [3145241604612, 8001841556957], [4146849330328, 593539761106]]
;
Number_of_curves:=#seq_j_inv;
Fp:=GF(p);
Fp2:=ExtensionField<Fp,z|&+[terms_irr_poly[i]*z^(i-1): i in [1..#terms_irr_poly]]>;

printf "\n p:=%o;",p;
printf "\n Defining polynomial=%o",DefiningPolynomial(Fp2);


R2<x,y>:=PolynomialRing(Fp2,2);


l:=PrimesInInterval(2,59)[StringToInteger(thread_id)];

mod_poly:=R2!ClassicalModularPolynomial(l);//The modular polynomial construction
never_walk_j_inv:=99*p^2+99;
printf "\n time to construct %o cycles FOR DIST=2 method and l=%o is",Number_of_curves,l;



time for i in [1..#seq_j_inv] do
	j0:=seq_j_inv[i][1]+seq_j_inv[i][2]*Fp2.1;	
	j:=j0;
	signal:=0;
	j_previous:=never_walk_j_inv;
	while(signal eq 0) do
		f:=Evaluate(mod_poly,y,j);
		set_of_roots:=Roots(UnivariatePolynomial(f));
		all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
		Exclude(~all_roots,j_previous);
		for t in [1..#all_roots] do
			j1:=all_roots[t];		
			j1_power_p:=j1^p;
			if(j1 eq j1_power_p) then
				break;
			else
				event1:=Evaluate(mod_poly,[j1,j1_power_p]) eq 0;	
				if(event1) then
					signal:=1;
					break;
				else
					f1:=Evaluate(mod_poly,y,j1);
					f2:=Evaluate(mod_poly,y,j1_power_p);
				event2:=GreatestCommonDivisor(UnivariatePolynomial(f1),UnivariatePolynomial(f2)) ne 1;
					if(event2) then
						signal:=1;
						break;
					end if;	
				end if;
			end if;
		end for;
		j_previous:=j;		
		j:=Random(all_roots);
	end while;	
end for;	
