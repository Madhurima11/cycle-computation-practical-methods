load "prime.m";
load "file_terms_irr_poly.m";
Fp2:=ExtensionField<Fp,z|&+[terms_irr_poly[i]*z^(i-1): i in [1..#terms_irr_poly]]>;

printf "\n p:=%o;",p;
printf "\n Defining polynomial=%o",DefiningPolynomial(Fp2);

load "list_ss_j_inv.m";

Number_of_curves:=#seq_j_inv;

Number_of_j_jp_isogenous_cases:=0;
list_my_cycles:=[];

R2<x,y>:=PolynomialRing(Fp2,2);
l:=3;mod_poly:=R2!ClassicalModularPolynomial(l);//The modular polynomial construction
R1<x>:=PolynomialRing(Fp2);



	
//Finding cycles by new method	
dist_2:=0;
dist_3:=0;
dist_4:=0;
d_2_i1_not_eq_i2:=0;
d_3_i1_not_eq_i2:=0;
d_4_i1_not_eq_i2:=0;
seq_number_of_edges_in_cycle_my_method:=[];	
printf "\n\n time to construct %o cycles by the new method is",#seq_j_inv;
time for i in [1..#seq_j_inv] do
	sign:=0;
	j:=seq_j_inv[i];	
	j0:=seq_j_inv[i];
	f:=Evaluate(mod_poly,y,j);
	set_of_roots:=Roots(UnivariatePolynomial(f));
	all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
	p_th_power_all_roots:=[(all_roots[i])^p : i in [1..#all_roots]];
	isogeneous_list_now:=[j];
	repeat
		if(not IsDisjoint(SequenceToSet(all_roots),SequenceToSet(p_th_power_all_roots))) then
			for i in [1..#all_roots] do
				j1:=all_roots[i];
				for t in [1..#p_th_power_all_roots] do
					j2:=p_th_power_all_roots[t];
					if(j1 eq j2) then
						dist_2:=dist_2+1;
						if(j2 ne (j1^p)) then
							d_2_i1_not_eq_i2:=d_2_i1_not_eq_i2+1;
						end if;
						Append(~isogeneous_list_now,j1);
					target_isogeny_initiating_index:=#isogeneous_list_now;
					target_isogeny_ending_index:=#isogeneous_list_now;
						sign:=1;
						break;
					end if;
				end for;
				if(sign eq 1) then
					break;
				end if;
			end for;
		
		else
			for i in [1..#all_roots] do
				j1:=all_roots[i];
				for t in [1..#p_th_power_all_roots] do
					j2:=p_th_power_all_roots[t];
					tmp:=Evaluate(mod_poly,[j1,j2]);
					if(tmp eq 0) then
						dist_3:=dist_3+1;
						if(j2 ne (j1^p)) then
							d_3_i1_not_eq_i2:=d_3_i1_not_eq_i2+1;
						end if;
						Append(~isogeneous_list_now,j1);
					target_isogeny_initiating_index:=#isogeneous_list_now;
						Append(~isogeneous_list_now,j2);
					target_isogeny_ending_index:=#isogeneous_list_now;
						sign:=1;
						break;
					end if;
				end for;
				if(sign eq 1) then
					break;
				end if;
			end for;
			if(sign eq 1) then
				break;
			end if;	
			for i in [1..#all_roots] do
				j1:=all_roots[i];
				for t in [1..#p_th_power_all_roots] do
					j2:=p_th_power_all_roots[t];	
					f1:=Evaluate(mod_poly,y,j1);
					f2:=Evaluate(mod_poly,y,j2);
					 		gcd:=GreatestCommonDivisor(UnivariatePolynomial(f1),UnivariatePolynomial(f2));
					if(gcd ne 1) then
						dist_4:=dist_4+1;
						if(j2 ne (j1^p)) then
							d_4_i1_not_eq_i2:=d_4_i1_not_eq_i2+1;
						end if;
						any_root:=Random(Roots(gcd))[1];
						Append(~isogeneous_list_now,j1);
					target_isogeny_initiating_index:=#isogeneous_list_now;
						Append(~isogeneous_list_now,any_root);
						Append(~isogeneous_list_now,j2);
					target_isogeny_ending_index:=#isogeneous_list_now;
						//printf "\n j1=%o, j2=%o END", j1,j2;
				 		sign:=1;
						break;
					 end if;
				end for;
				if(sign eq 1) then
					break;
				end if;	
			end for;
			if(sign eq 0) then
				
				j:=Random(set_of_roots)[1];
				//printf "j=%o --> ",j;		
				f:=Evaluate(mod_poly,y,j);
				set_of_roots:=Roots(UnivariatePolynomial(f));
				all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
				p_th_power_all_roots:=[(all_roots[i])^p : i in [1..#all_roots]];
				Append(~isogeneous_list_now,j);
	
			end if;
		end if;
	until(sign eq 1);
	adding_reverse_from:=target_isogeny_initiating_index-1;
	half_cycle_now:=isogeneous_list_now;
	N:=adding_reverse_from;

	while(N gt 0) do
		Append(~half_cycle_now,isogeneous_list_now[N]^p);
		N:=N-1;
	end while;
	

	if(j0 in Fp) then
		Append(~seq_number_of_edges_in_cycle_my_method,2*(#half_cycle_now-1));	
	else
		Append(~seq_number_of_edges_in_cycle_my_method,#half_cycle_now);
	end if;
end for;	
printf "\nseq_number_of_edges_in_cycle_my_method=%o",seq_number_of_edges_in_cycle_my_method;
printf "\n mean of the number of edges in cycle by my method=%o",RealField(5)!(&+[seq_number_of_edges_in_cycle_my_method[i]: i in [1..Number_of_curves]]/Number_of_curves);
half_cycle_now;
printf "\n dist_2=%o",dist_2;
printf "\n dist_3=%o",dist_3;
printf "\n dist_4=%o",dist_4;
printf "\n d_2_i1_not_eq_i2=%o",d_2_i1_not_eq_i2;
printf "\n d_3_i1_not_eq_i2=%o",d_3_i1_not_eq_i2;
printf "\n d_4_i1_not_eq_i2=%o",d_4_i1_not_eq_i2;
printf "\nl=%o",l;
