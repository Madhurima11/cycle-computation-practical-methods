terms_irr_poly:=
[ 17925, 13006, 1 ]
;
