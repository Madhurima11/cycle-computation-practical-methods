load "prime.m";
load "file_terms_irr_poly.m";
Fp2:=ExtensionField<Fp,z|&+[terms_irr_poly[i]*z^(i-1): i in [1..#terms_irr_poly]]>;

printf "\n p:=%o;",p;
printf "\n Defining polynomial=%o",DefiningPolynomial(Fp2);

load "list_ss_j_inv.m";


Number_of_curves:=#seq_j_inv;

//Number_of_j_jp_isogenous_cases:=0;
//list_my_cycles:=[];

R2<x,y>:=PolynomialRing(Fp2,2);
//The modular polynomial construction
R1<x>:=PolynomialRing(Fp2);

never_walk_j_inv:=99*p^2+99;
//seq_number_of_edges_in_cycle_my_method:=[];
	

function InvFreeGCD(poly1, poly2)
	r:=LeadingCoefficient(poly2)*poly1;
	s:=LeadingCoefficient(poly1)*poly2;
	if(Degree(r) le Degree(s)) then
			tmp:=r;
			r:=s;
			s:=tmp;
	end if;
	n:=Degree(r)-Degree(s);
	while ((Degree(r) ge 1) and (r ne ((x^n)*s))) do		
		r:=r-((x^n)*s);
		tmp:=r;
		r:=LeadingCoefficient(s)*r;
		s:=LeadingCoefficient(tmp)*s;	
		n:=Degree(r)-Degree(s);
		if(n le 0) then
			tmp:=r;
			r:=s;
			s:=tmp;
			n:=-n;
		end if;
		
	end while;
	if((Degree(r) eq 1) and ((Degree(s) eq 1))) then
		return 1;
	else
		return 0;
	end if;		
end function;
function dist_2_to_j_p(mod_poly_at_j)
	a_i_seq:=Coefficients(mod_poly_at_j,1);
	a_i_seq:=[ElementToSequence(Fp2!a_i_seq[i]): i in [1..#a_i_seq]];
	g_1:=&+[a_i_seq[i][1]*x^(i-1):i in [1..#a_i_seq]];
	g_2:=&+[a_i_seq[i][2]*x^(i-1):i in [1..(#a_i_seq-1)]];

	return InvFreeGCD(g_1,g_2);
end function;


function element_in_Fp(seq)
	for i in [1..#seq] do
		s:=seq[i];
		if(s in Fp) then
			return s;
		end if;
	end for;
end function;

printf "\n\n time to construct %o cycles by the new method is",#seq_j_inv;

l:=2;

time while(l le 59) do
	printf "\n l=%o",l;
	mod_poly:=R2!ClassicalModularPolynomial(l);
	time for i in [1..#seq_j_inv] do
		sign:=0;
		j0:=seq_j_inv[i];
		j:=j0;	
		j_previous:=never_walk_j_inv; 
		path:=[j0];
		while(sign eq 0) do
			
			if(j in Fp) then
				sign:=1;
				break;
			else
				j_power_p:=j^p; 
				f:=Evaluate(mod_poly,y,j);
				f_univariate:=UnivariatePolynomial(f);
				if(Evaluate(f_univariate,j_power_p) eq 0) then
					Include(~path,j_power_p);
					sign:=1;
					break;
				else
				
					if(dist_2_to_j_p(f) eq 1)then						
						set_of_roots:=Roots(f_univariate);
						all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
						r_p:=element_in_Fp(all_roots);
						Include(~path,r_p);
						Include(~path,j_power_p);
						sign:=1;
						break;		
					
					else
						set_of_roots:=Roots(f_univariate);
						all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
						Exclude(~all_roots,j_previous);	
						j_1:=Random(all_roots);//the root at the intermediate step	
						j_1_power_p:=j_1^p;
												
						g:=Evaluate(mod_poly,y,j_1);
														g_univariate:=UnivariatePolynomial(g);	
						if(Evaluate(g_univariate,j_1_power_p) eq 0) then
							Include(~path,j_1);
							Include(~path,j_1_power_p);
							Include(~path,j_power_p);
						
							sign:=1;
							break;	
						end if;	
					end if;
				end if;	
			end if;
			set_of_roots:=Roots(g_univariate);
			all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];	
			Exclude(~all_roots,j);	
			j_previous:=j_1;
			j:=Random(all_roots);
			Include(~path,j);
		end while;
	end for;
	l:=NextPrime(l);
end while;		


