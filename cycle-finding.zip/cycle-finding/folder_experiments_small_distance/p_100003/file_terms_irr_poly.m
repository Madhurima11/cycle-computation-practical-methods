terms_irr_poly:=
[ 39829, 80562, 1 ]
;
