p:= 1099511627689
;
terms_irr_poly:= [7, 0, 1]
;
seq_j_inv:= [[87693622798, 523525629282], [535745503640, 107693312759], [641494603188, 910270261802], [6854270853, 43311187292], [607238704218, 657073896440], [664246704806, 683752361452], [60598529427, 798174702376], [165267646652, 897633470086], [794462756525, 304054990211], [659631537455, 79721855920], [931562720768, 69414499998], [506140543764, 941536353180], [84063053383, 997079106618], [192584245000, 754555698650], [1093474119349, 937273503421], [736779488373, 978505553068], [762256433588, 519213546292], [144810452767, 3836918522], [942899106255, 525785607244], [564455221682, 209517788699]]
;
Number_of_curves:=#seq_j_inv;
Fp:=GF(p);
Fp2:=ExtensionField<Fp,z|&+[terms_irr_poly[i]*z^(i-1): i in [1..#terms_irr_poly]]>;

printf "\n p:=%o;",p;
printf "\n Defining polynomial=%o",DefiningPolynomial(Fp2);


R2<x,y>:=PolynomialRing(Fp2,2);


l:=PrimesInInterval(2,59)[StringToInteger(thread_id)];

mod_poly:=R2!ClassicalModularPolynomial(l);//The modular polynomial construction
never_walk_j_inv:=99*p^2+99;
printf "\n time to construct %o cycles FOR DIST=2 method and l=%o is",Number_of_curves,l;



time for i in [1..#seq_j_inv] do
	j0:=seq_j_inv[i][1]+seq_j_inv[i][2]*Fp2.1;	
	j:=j0;
	signal:=0;
	j_previous:=never_walk_j_inv;
	while(signal eq 0) do
		f:=Evaluate(mod_poly,y,j);
		set_of_roots:=Roots(UnivariatePolynomial(f));
		all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
		Exclude(~all_roots,j_previous);
		for t in [1..#all_roots] do
			j1:=all_roots[t];		
			j1_power_p:=j1^p;
			if(j1 eq j1_power_p) then
				break;
			else
				event1:=Evaluate(mod_poly,[j1,j1_power_p]) eq 0;	
				if(event1) then
					signal:=1;
					break;
				else
					f1:=Evaluate(mod_poly,y,j1);
					f2:=Evaluate(mod_poly,y,j1_power_p);
				event2:=GreatestCommonDivisor(UnivariatePolynomial(f1),UnivariatePolynomial(f2)) ne 1;
					if(event2) then
						signal:=1;
						break;
					end if;	
				end if;
			end if;
		end for;
		j_previous:=j;		
		j:=Random(all_roots);
	end while;	
end for;	
