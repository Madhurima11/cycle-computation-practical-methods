p:= 2199023255531
;
terms_irr_poly:= [1, 0, 1]
;
seq_j_inv:= [[1797300613784, 435041744831], [1222240813549, 696921056349], [106710047993, 1819799712215], [1966877947280, 458596635563], [1200601323036, 2195584789177], [1761458881166, 1278100221885], [914647868345, 1039319909449], [1426614157084, 1580291997133], [1065430312775, 943067030521], [1151974815414, 1374203949941], [2054982924943, 1923860580421], [1849914337998, 671211227945], [1467853134702, 733031509515], [2070813326738, 1684887508144], [1022307827879, 1472054922445], [201343604079, 1980010339106], [870710436782, 1807500055926], [1298223632970, 1447785354265], [1015400567156, 1240852756535], [1782290192100, 324857920576], [228885904870, 940716406787], [2032402882547, 1141626522461], [1050174819908, 2102775133876], [1025893554739, 2039860990328], [2125974387597, 258825837685], [1377626123766, 1894258792605], [1284438986022, 1031162738154], [840121005077, 96364182241], [2150089963369, 229053108047], [1397435023166, 1630806180726], [243323526615, 814828545355], [1848625966962, 909106318555], [1385878671915, 2177327849176], [658470591371, 1903056791103], [798084151643, 2016164792530], [380081021317, 916578628396], [1950396701285, 1378465229687], [1420479335624, 1489301259133], [30597411762, 1009522049768], [1942925271709, 1318211276907]]
;
Number_of_curves:=#seq_j_inv;
Fp:=GF(p);
Fp2:=ExtensionField<Fp,z|&+[terms_irr_poly[i]*z^(i-1): i in [1..#terms_irr_poly]]>;

printf "\n p:=%o;",p;
printf "\n Defining polynomial=%o",DefiningPolynomial(Fp2);


R2<x,y>:=PolynomialRing(Fp2,2);


l:=PrimesInInterval(2,59)[StringToInteger(thread_id)];

mod_poly:=R2!ClassicalModularPolynomial(l);//The modular polynomial construction
never_walk_j_inv:=99*p^2+99;
printf "\n time to construct %o cycles FOR DIST=2 method and l=%o is",Number_of_curves,l;



time for i in [1..#seq_j_inv] do
	j0:=seq_j_inv[i][1]+seq_j_inv[i][2]*Fp2.1;	
	j:=j0;
	signal:=0;
	j_previous:=never_walk_j_inv;
	while(signal eq 0) do
		f:=Evaluate(mod_poly,y,j);
		set_of_roots:=Roots(UnivariatePolynomial(f));
		all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
		Exclude(~all_roots,j_previous);
		for t in [1..#all_roots] do
			j1:=all_roots[t];		
			j1_power_p:=j1^p;
			if(j1 eq j1_power_p) then
				break;
			else
				event1:=Evaluate(mod_poly,[j1,j1_power_p]) eq 0;	
				if(event1) then
					signal:=1;
					break;
				else
					f1:=Evaluate(mod_poly,y,j1);
					f2:=Evaluate(mod_poly,y,j1_power_p);
				event2:=GreatestCommonDivisor(UnivariatePolynomial(f1),UnivariatePolynomial(f2)) ne 1;
					if(event2) then
						signal:=1;
						break;
					end if;	
				end if;
			end if;
		end for;
		j_previous:=j;		
		j:=Random(all_roots);
	end while;	
end for;		
