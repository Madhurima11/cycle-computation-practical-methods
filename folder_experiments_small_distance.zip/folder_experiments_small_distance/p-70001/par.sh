magma all_l_i_1_cycle_finding.m > out1_all_l_i_1_cycle_finding.txt &
magma all_l_i_1_cycle_finding.m > out2_all_l_i_1_cycle_finding.txt &
magma all_l_i_1_cycle_finding.m > out3_all_l_i_1_cycle_finding.txt &
magma all_l_i_1_cycle_finding.m > out4_all_l_i_1_cycle_finding.txt &
magma all_l_i_1_cycle_finding.m > out5_all_l_i_1_cycle_finding.txt &

magma all_l_gcd_eq_1_semi_i_3_cycle_finding.m > out1_all_l_gcd_eq_1_semi_i_3_cycle_finding.txt &
magma all_l_gcd_eq_1_semi_i_3_cycle_finding.m > out2_all_l_gcd_eq_1_semi_i_3_cycle_finding.txt &
magma all_l_gcd_eq_1_semi_i_3_cycle_finding.m > out3_all_l_gcd_eq_1_semi_i_3_cycle_finding.txt &
magma all_l_gcd_eq_1_semi_i_3_cycle_finding.m > out4_all_l_gcd_eq_1_semi_i_3_cycle_finding.txt &
magma all_l_gcd_eq_1_semi_i_3_cycle_finding.m > out5_all_l_gcd_eq_1_semi_i_3_cycle_finding.txt &



