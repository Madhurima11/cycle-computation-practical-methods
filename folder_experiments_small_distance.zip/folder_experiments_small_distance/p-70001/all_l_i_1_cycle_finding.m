load "prime.m";
load "file_terms_irr_poly.m";
Fp2:=ExtensionField<Fp,z|&+[terms_irr_poly[i]*z^(i-1): i in [1..#terms_irr_poly]]>;

printf "\n p:=%o;",p;
printf "\n Defining polynomial=%o",DefiningPolynomial(Fp2);

load "list_ss_j_inv.m";


Number_of_curves:=#seq_j_inv;



R2<x,y>:=PolynomialRing(Fp2,2);

R1<x>:=PolynomialRing(Fp2);

never_walk_j_inv:=99*p^2+99;


printf "\n\n time to construct %o cycles by the new method is",#seq_j_inv;

l:=2;
time while(l le 59) do
	printf "\n l=%o",l;
	mod_poly:=R2!ClassicalModularPolynomial(l);
	time for i in [1..#seq_j_inv] do
		sign:=0;
		j0:=seq_j_inv[i];
		j:=j0;	
		j_previous:=never_walk_j_inv;
		path:=[j0];
		while(sign eq 0) do
			
			if(j in Fp) then
				sign:=1;
				break;
			else
				j_power_p:=j^p;
				f:=Evaluate(mod_poly,y,j);
				f_univariate:=UnivariatePolynomial(f);
				if(Evaluate(f_univariate,j_power_p) eq 0) then
					Include(~path,j_power_p);
					sign:=1;
					break;
				end if;	
			end if;
			set_of_roots:=Roots(f_univariate);
			all_roots:=[set_of_roots[i][1] : i in [1..#set_of_roots]];
			Exclude(~all_roots,j_previous);
			j_previous:=j;
			j:=Random(all_roots);
			Include(~path,j);
		end while;
	end for;
	l:=NextPrime(l);
end while;		

